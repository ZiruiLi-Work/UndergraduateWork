I=imread('CQUPT.jpg');
imwrite(I,'CQUPT.jpg','bmp');
imwrite(I,'C:\Users\Administrator\Desktop\CQUPT.jpg','bmp');
