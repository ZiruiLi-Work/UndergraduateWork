function [a,b]=change(x,y)
a=y
b=x