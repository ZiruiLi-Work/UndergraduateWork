a=[3 2 1;1 3 2;2 3 1];
b=exp(a)
c=log(a)
d=sqrt(a)