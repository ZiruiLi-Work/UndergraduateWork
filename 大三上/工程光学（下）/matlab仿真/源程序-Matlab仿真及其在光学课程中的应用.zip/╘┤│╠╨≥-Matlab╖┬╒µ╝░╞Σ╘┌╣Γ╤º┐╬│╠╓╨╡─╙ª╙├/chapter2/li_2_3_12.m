a=[1 2 3];b=4:6;c=[3 2 1];
d=a+b
e=a+1
f=2*a
g=dot(a,b)
h=cross(a,b) 
i=dot(a,cross(b,c))