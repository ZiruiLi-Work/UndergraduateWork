student.number='02110875';
student.name='����';
student.sex='Ů';
student.age='21';
student.class='03';
student.department='02';
student       