p1=[3 0 2 -5];
p2=[0 0 5 2];
T1=poly2sym(p1+p2)
T2=poly2sym(p1-p2)