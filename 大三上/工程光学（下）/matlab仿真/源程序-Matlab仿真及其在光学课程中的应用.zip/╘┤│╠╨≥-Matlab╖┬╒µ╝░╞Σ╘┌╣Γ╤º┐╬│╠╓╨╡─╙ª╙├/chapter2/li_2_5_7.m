p1=[3 0 2 -5];
h1=polyval(p1,[3 5])
h2=polyvalm(p1,[3 5;2 4])