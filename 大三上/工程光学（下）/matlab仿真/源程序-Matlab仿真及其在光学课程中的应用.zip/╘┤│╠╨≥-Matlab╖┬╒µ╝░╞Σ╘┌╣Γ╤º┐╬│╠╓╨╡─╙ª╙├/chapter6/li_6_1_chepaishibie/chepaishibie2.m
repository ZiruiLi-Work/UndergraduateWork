I=imread('E:\car.jpg'); 
I1=rgb2gray(I); 
I2=edge(I1,'roberts',0.09,'both');   
se=[1;1;1]; 
I3=imerode(I2,se); 
se=strel('rectangle',[25,25]); 
I4=imclose(I3,se);  
I5=bwareaopen(I4,1000);
[y,x,z]=size(I5);
I6=double(I5);
Y1=zeros(y,1);
for i=1:y
for j=1:x
if(I6(i,j,1)==1)
Y1(i,1)= Y1(i,1)+1;
 end
 end
end
figure();
subplot(1,2,1);
plot(0:y-1,Y1),title('�����ػҶ�ֵ�ۼ�');
xlabel('��ֵ'),ylabel('���غ�'); 
 [temp, MaxY]=max(Y1);
PY1=MaxY;
while ((Y1(PY1,1)>=5)&&(PY1>1))
PY1=PY1-1;
end
PY2=MaxY;
while ((Y1(PY2,1)>=5)&&(PY2<y))
PY2=PY2+1;
end
X1=zeros(1,x);
for j=1:x
for i=PY1:PY2
if(I6(i,j,1)==1)
X1(1,j)= X1(1,j)+1;
end
end
end
subplot(1,2,2);
plot(0:x-1,X1),title('�����ػҶ�ֵ�ۼ�');
xlabel('��ֵ'),ylabel('������');
PX1=1;
while ((X1(1,PX1)<3)&&(PX1<x))
PX1=PX1+1;
end
PX2=x;
while ((X1(1,PX2)<3)&&(PX2>PX1))
PX2=PX2-1;
end
PX1=PX1-1; 
PX2=PX2+1; 
