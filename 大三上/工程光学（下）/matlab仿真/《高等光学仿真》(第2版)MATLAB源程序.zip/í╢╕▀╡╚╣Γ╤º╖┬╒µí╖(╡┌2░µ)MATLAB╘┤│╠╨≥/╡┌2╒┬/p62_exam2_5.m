N = 11;
b = linspace(0,1,201);
V = zeros(length(b),N);

for k = 1:N
    V(:,k) = ((k-1)*pi + 2*atan(sqrt(b./(1-b))))./sqrt(1-b);
    plot(V(:,k),b)
    text(V(180-k*10,k)-1,b(180-k*10),['N=' num2str(k-1)])
    hold on
    axis([0 50 0 1])
end 
xlabel('V')
ylabel('b')