syms x y
vpa(int(int(y*sin(x)+x*cos(y),x,pi,2*pi),y,0,pi))