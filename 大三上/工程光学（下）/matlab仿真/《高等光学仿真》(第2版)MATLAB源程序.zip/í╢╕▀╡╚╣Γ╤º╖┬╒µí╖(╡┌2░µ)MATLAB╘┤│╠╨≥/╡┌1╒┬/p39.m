x = 0:.01:5;
semilogy(x, exp(x)), 
grid on