x = 0:pi/100:2*pi;
polar(x, sin(4*x))
grid on