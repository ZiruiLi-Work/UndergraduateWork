gL = @(v)(2/pi./(1+v.^2));
ezplot(gL);
grid on