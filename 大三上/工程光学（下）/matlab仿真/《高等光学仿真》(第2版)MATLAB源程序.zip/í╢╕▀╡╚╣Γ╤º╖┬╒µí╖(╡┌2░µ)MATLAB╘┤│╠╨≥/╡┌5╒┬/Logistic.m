function dydx = Logistic(x,y)
    dydx = 1/3*y*(8-y);