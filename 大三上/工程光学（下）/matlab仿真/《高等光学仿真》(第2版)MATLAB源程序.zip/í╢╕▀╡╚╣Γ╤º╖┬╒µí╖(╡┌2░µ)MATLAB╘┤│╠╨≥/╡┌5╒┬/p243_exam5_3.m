gL = @(v)(2*sqrt(log(2)/pi)*exp(-v.^2*log(2)));
ezplot(gL);
grid on