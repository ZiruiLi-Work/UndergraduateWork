[X,Y] = meshgrid(-8:.5:8);
R = sqrt(X.^2 + Y.^2) + eps;
Z = sin(R)./R;
[C, h] = contour(X,Y,Z);
colormap gray
colorbar
set(h,'ShowText','on','TextStep',get(h,'LevelStep'))