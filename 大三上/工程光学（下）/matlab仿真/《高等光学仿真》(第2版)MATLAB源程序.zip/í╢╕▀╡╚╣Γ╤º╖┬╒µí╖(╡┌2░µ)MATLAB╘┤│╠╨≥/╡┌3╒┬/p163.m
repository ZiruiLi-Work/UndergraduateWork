Z = peaks;
figure('Renderer','zbuffer');
surfc(Z);
axis tight manual;
set(gca,'NextPlot','replaceChildren');
for j = 1:20
    surfc(sin(2*pi*j/20)*Z)
    F(j) = getframe;
end
movie(F,20) %���Ŷ���20��