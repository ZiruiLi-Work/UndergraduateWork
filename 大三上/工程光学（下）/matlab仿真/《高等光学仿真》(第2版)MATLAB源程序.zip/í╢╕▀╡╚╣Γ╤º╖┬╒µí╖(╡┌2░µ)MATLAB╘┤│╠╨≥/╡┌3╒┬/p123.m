%���ɶ���
numFrames = 100;                %���ö�������֡��
mov = moviein(numFrames);
figure('Renderer','zbuffer');   %����ͼ�δ���
surf(X1,Y1,E1)
shading interp
xlabel('x'),ylabel('y'),zlabel('I')
title(['LP_{01} Mode, V = ' num2str(V)])
axis([-inf,inf,-inf,inf,-1,1])
set(gca,'NextPlot','replaceChildren');

for k = 1:numFrames
    scale = cos(2*pi*k/numFrames);
    surf(X1,Y1,E1*scale)
    shading interp
    xlabel('x'),ylabel('y'),zlabel('I')
    title(['LP_{01} Mode, V = ' num2str(V)])
    axis([-inf,inf,-inf,inf,-1,1])
    view([-38,12])
    hold on
    surf(X2,Y2,E2*scale)
    shading interp
    axis([-inf,inf,-inf,inf,-1,1])
    mov(k) = getframe;
    hold off
end
movie(mov)  %���Ŷ���

%�������洢Ϊ GIF �ļ�������
animated(1,1,1,numFrames) = 0;
for k=1:numFrames
    if k == 1
        [animated, cmap] = rgb2ind(mov(k).cdata,256,'nodither');
    else
        animated(:,:,1,k) = rgb2ind(mov(k).cdata,cmap,'nodither');
    end
end
filename = 'LP01.gif';
imwrite(animated,cmap,filename,'DelayTime',0.1,'LoopCount', inf);
web(filename)