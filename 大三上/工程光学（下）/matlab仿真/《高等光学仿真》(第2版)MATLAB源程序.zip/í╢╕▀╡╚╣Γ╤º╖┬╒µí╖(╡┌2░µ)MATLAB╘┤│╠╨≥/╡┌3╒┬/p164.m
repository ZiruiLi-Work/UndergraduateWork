clc,clear,close all;
fig = figure;
aviobj = avifile('example.avi');    %����������avi�ļ����ļ���
n = 100;
t = 0:2*pi/n:2*pi;
x = cos(t);
y = sin(t);
for k = 1:n
    x(k) = cos(t(k));
    y(k) = sin(t(k));
    H = plot(x,y,x(k),y(k),'or',x(k),-y(k),'ob');
    axis equal
    grid on
    MOV = getframe(fig);
    aviobj = addframe(aviobj,MOV);
end 
close(fig) 
aviobj = close(aviobj)