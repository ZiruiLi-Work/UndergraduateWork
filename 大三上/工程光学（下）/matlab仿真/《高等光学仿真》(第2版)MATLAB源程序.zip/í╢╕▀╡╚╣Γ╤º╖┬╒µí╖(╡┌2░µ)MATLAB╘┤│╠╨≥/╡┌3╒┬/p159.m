subplot(2,2,1), sphere(4), title('N=4')
subplot(2,2,2), sphere(8), title('N=8')
subplot(2,2,3), sphere,    title('N=20')
subplot(2,2,4), sphere(40), title('N=40')