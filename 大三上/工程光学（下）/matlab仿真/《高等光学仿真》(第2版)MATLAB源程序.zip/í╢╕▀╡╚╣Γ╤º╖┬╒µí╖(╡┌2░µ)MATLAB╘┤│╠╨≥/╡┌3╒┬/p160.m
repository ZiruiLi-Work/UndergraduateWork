[x,y,z]=cylinder(1.1+sin(0:0.25:2*pi),16);
surf(x,y,z)
colorbar