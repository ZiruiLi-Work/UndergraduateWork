vx = 100*cos(1/3*pi);
vy = 100*sin(1/3*pi);
t = 0:0.005:18;
x = vx*t;
y = vy*t-9.8*t.^2/2;
comet(x,y)